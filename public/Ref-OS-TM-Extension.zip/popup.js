// src/tmAddress.js
function normalizeTmAddress(value) {
  const entered = String(value ?? "").trim();
  if (!entered) throw Error("Enter the TM server IP address or hostname.");
  const address = /^[a-z][a-z\d+.-]*:\/\//i.test(entered) ? entered : `http://${entered}`;
  let url;
  try {
    url = new URL(address);
  } catch {
    throw Error("Enter a valid TM server IP address or hostname, with its port if needed.");
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== "/") throw Error("Use only the TM server address and optional port.");
  return url.origin;
}

// browser-extension/security.js
var hostPattern = (value) => {
  const u = new URL(normalizeTmAddress(value));
  return `${u.protocol}//${u.hostname}/*`;
};
var hostPatterns = (value) => {
  const pattern = hostPattern(value);
  return [pattern, pattern.replace(/^http:/, "ws:").replace(/^https:/, "wss:")];
};

// browser-extension/popup.js
var input = document.querySelector("#address");
var status = document.querySelector("#status");
chrome.storage.local.get("address").then(({ address }) => {
  input.value = address || "";
  status.textContent = address ? "Server configured. Open Ref OS to connect." : "";
});
document.querySelector("form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const address = normalizeTmAddress(input.value), pattern = hostPattern(address);
    const granted = await chrome.permissions.request({ origins: hostPatterns(address) });
    if (!granted) throw Error("Server access was not allowed. School IT may need to approve it.");
    const previous = await chrome.storage.local.get("address");
    await chrome.storage.local.set({ address });
    if (previous.address && hostPattern(previous.address) !== pattern) await chrome.permissions.remove({ origins: hostPatterns(previous.address) });
    status.textContent = "TM server allowed. Reload Ref OS, then open TM Sync Center.";
  } catch (error) {
    status.textContent = error.message;
  }
});
document.querySelector("#open").addEventListener("click", () => chrome.tabs.create({ url: "https://www.ref-os.fyi/" }));
document.querySelector("#remove").addEventListener("click", async () => {
  const { address } = await chrome.storage.local.get("address");
  await chrome.storage.local.remove("address");
  if (address) await chrome.permissions.remove({ origins: hostPatterns(address) });
  input.value = "";
  status.textContent = "Server access removed.";
});
