// src/tmAddress.js
function normalizeTmAddress(value) {
  const entered = String(value ?? "").trim();
  if (!entered) throw Error("Enter the TM server IP address or hostname.");
  const address = /^[a-z][a-z\d+.-]*:\/\//i.test(entered) ? entered : `http://${entered}`;
  let url;
  try {
    url = new URL(address);
  } catch {
    throw Error("Enter a valid TM server IP address or hostname, with its port if needed.");
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== "/") throw Error("Use only the TM server address and optional port.");
  return url.origin;
}

// browser-extension/security.js
var hostPattern = (value) => {
  const u = new URL(normalizeTmAddress(value));
  return `${u.protocol}//${u.hostname}/*`;
};
var hostPatterns = (value) => {
  const pattern = hostPattern(value);
  return [pattern, pattern.replace(/^http:/, "ws:").replace(/^https:/, "wss:")];
};

// browser-extension/popup.js
var input = document.querySelector("#address");
var status = document.querySelector("#status");
chrome.storage.local.get("address").then(({ address }) => {
  input.value = address || "";
  status.textContent = address ? "Server configured. Open Ref OS to connect." : "";
});
var keyInput = document.querySelector("#apiKey");
chrome.storage.session.get("tmCredentials").then(({ tmCredentials }) => {
  keyInput.value = tmCredentials?.apiKey || "";
});
document.querySelector("form:not(#venueForm)").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const address = normalizeTmAddress(input.value), pattern = hostPattern(address);
    const granted = await chrome.permissions.request({ origins: hostPatterns(address) });
    if (!granted) throw Error("Server access was not allowed. School IT may need to approve it.");
    const previous = await chrome.storage.local.get("address");
    await chrome.storage.local.set({ address });
    await chrome.storage.session.set({ tmCredentials: { address, apiKey: keyInput.value.trim() } });
    if (previous.address && hostPattern(previous.address) !== pattern) await releaseUnusedHost(previous.address);
    status.textContent = "Connection saved. Open TM Sync Center in Ref OS; your address and key will fill in automatically.";
  } catch (error) {
    status.textContent = error.message;
  }
});
document.querySelector("#open").addEventListener("click", () => chrome.tabs.create({ url: "https://www.ref-os.fyi/" }));
document.querySelector("#remove").addEventListener("click", async () => {
  const { address } = await chrome.storage.local.get("address");
  await chrome.storage.local.remove("address");
  await chrome.storage.session.remove("tmCredentials");
  keyInput.value = "";
  if (address) await releaseUnusedHost(address);
  input.value = "";
  status.textContent = "Server access removed.";
});
var venueInput = document.querySelector("#venueAddress");
var venueStatus = document.querySelector("#venueStatus");
var venueOpen = document.querySelector("#venueOpen");
var venueAddress = "";
chrome.storage.local.get("venueAddress").then((saved) => {
  venueAddress = saved.venueAddress || "";
  venueInput.value = venueAddress;
  venueOpen.disabled = !venueAddress;
});
document.querySelector("#venueForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  venueStatus.textContent = "Checking venue server\u2026";
  try {
    const address = normalizeTmAddress(venueInput.value);
    const allowed = await chrome.permissions.request({ origins: hostPatterns(address) });
    if (!allowed) throw Error("Venue access was not allowed. Ask school IT to approve it.");
    const response = await fetch(address + "/api/v1/health", { credentials: "omit", redirect: "error", signal: AbortSignal.timeout(5e3) });
    if (!response.ok) throw Error("Venue server returned HTTP " + response.status + ". Check the server app.");
    const health = await response.json();
    if (health.service !== "refos-venue-server") throw Error("That address is not a Ref-OS venue server. Check its IP address and port.");
    const oldVenue = venueAddress;
    await chrome.storage.local.set({ venueAddress: address });
    venueAddress = address;
    if (oldVenue) await releaseUnusedHost(oldVenue);
    venueOpen.disabled = false;
    venueStatus.textContent = "Venue server connected. Open venue Ref-OS and sign in to your event.";
  } catch (error) {
    venueStatus.textContent = error.name === "TimeoutError" ? "Server did not respond. Start the host app, connect to the same Wi-Fi, and check the address and firewall." : error instanceof TypeError ? "Could not reach the server. Start the host app, check the IP and port, and ask IT about Wi-Fi device isolation." : error.message;
  }
});
venueOpen.addEventListener("click", () => {
  if (venueAddress) chrome.tabs.create({ url: venueAddress });
});
document.querySelector("#venueRemove").addEventListener("click", async () => {
  const oldVenue = venueAddress;
  await chrome.storage.local.remove("venueAddress");
  venueAddress = "";
  if (oldVenue) await releaseUnusedHost(oldVenue);
  venueInput.value = "";
  venueOpen.disabled = true;
  venueStatus.textContent = "Venue address forgotten.";
});
async function releaseUnusedHost(oldAddress) {
  const saved = await chrome.storage.local.get(["address", "venueAddress"]);
  if ([saved.address, saved.venueAddress].filter(Boolean).some((value) => hostPattern(value) === hostPattern(oldAddress))) return;
  await chrome.permissions.remove({ origins: hostPatterns(oldAddress) });
}
