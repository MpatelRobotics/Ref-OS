// src/tmAddress.js
function normalizeTmAddress(value) {
  const entered = String(value ?? "").trim();
  if (!entered) throw Error("Enter the TM server IP address or hostname.");
  const address = /^[a-z][a-z\d+.-]*:\/\//i.test(entered) ? entered : `http://${entered}`;
  let url;
  try {
    url = new URL(address);
  } catch {
    throw Error("Enter a valid TM server IP address or hostname, with its port if needed.");
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== "/") throw Error("Use only the TM server address and optional port.");
  return url.origin;
}

// src/tmFieldEvent.js
var positive = (n) => Number.isSafeInteger(n) && n > 0;
var nonnegative = (n) => Number.isSafeInteger(n) && n >= 0;
function applyFieldEvent(set, message, now = Date.now()) {
  if (!message || typeof message !== "object") return false;
  if (message.type === "audienceDisplayChanged") {
    if (typeof message.display !== "string" || message.display.length > 100) return false;
    set.display = message.display;
    return true;
  }
  const field = set.fields.find((row) => row.id === message.fieldID);
  if (!field) return false;
  if (message.type === "fieldMatchAssigned") {
    const m = message.match;
    if (!m || !positive(m.division) || !nonnegative(m.session) || !positive(m.match) || !positive(m.instance) || typeof m.round !== "string" || m.round.length > 30) return false;
    field.match = { division: m.division, session: m.session, round: m.round, match: m.match, instance: m.instance };
    field.status = "queued";
    field.startedAt = null;
  } else if (message.type === "fieldActivated") {
    for (const row of set.fields) row.active = row === field;
  } else if (message.type === "matchStarted") {
    field.status = "playing";
    field.startedAt = now;
  } else if (message.type === "matchStopped") field.status = "stopped";
  else return false;
  field.observedAt = now;
  return true;
}

// src/tmMobileClient.js
async function mobileSignedHeaders(url, path, key, token, date = (/* @__PURE__ */ new Date()).toUTCString(), signer) {
  const message = `GET
${path}
token:${token}
host:${url.host}
x-tm-date:${date}
`;
  if (signer) return { Authorization: `Bearer ${token}`, "x-tm-date": date, "x-tm-signature": (await signer({ key, message })).signature };
  const encoder = new TextEncoder();
  const secret = await crypto.subtle.importKey("raw", encoder.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", secret, encoder.encode(message));
  return { Authorization: `Bearer ${token}`, "x-tm-date": date, "x-tm-signature": [...new Uint8Array(signature)].map((n) => n.toString(16).padStart(2, "0")).join("") };
}
function createMobileTmClient({ http, sockets, cloudUrl, now = Date.now }) {
  let connectionId = "", identity = "", generation = 0, operation = 0, leaseUntil = 0, listener;
  const states = /* @__PURE__ */ new Map(), retries = /* @__PURE__ */ new Map(), attempts = /* @__PURE__ */ new Map();
  const sign = (url, path, key, token) => mobileSignedHeaders(url, path, key, token, new Date(now()).toUTCString(), sockets.sign ? (options) => sockets.sign(options) : void 0);
  const close = async () => {
    generation++;
    connectionId = "";
    identity = "";
    leaseUntil = 0;
    for (const timer of retries.values()) clearTimeout(timer);
    retries.clear();
    states.clear();
    attempts.clear();
    const previousListener = listener;
    listener = void 0;
    if (previousListener) await previousListener.remove();
    await sockets.closeAll();
  };
  const configure = async (url, body, token, sets, snapshotOperation) => {
    const nextIdentity = JSON.stringify([body.eventId, url.origin, body.apiKey, body.division, token, sets]);
    if (identity === nextIdentity) {
      leaseUntil = now() + 9e4;
      return;
    }
    await close();
    if (snapshotOperation !== operation) throw Error("TM connection cancelled.");
    identity = nextIdentity;
    connectionId = [...crypto.getRandomValues(new Uint8Array(16))].map((n) => n.toString(16).padStart(2, "0")).join("");
    leaseUntil = now() + 9e4;
    const ticket = generation;
    const connect = async (id) => {
      if (ticket !== generation) return;
      const state = states.get(id);
      state.connected = false;
      state.fields.forEach((f) => {
        f.status = "unknown";
        f.match = null;
        f.active = false;
      });
      const path = `/api/fieldsets/${state.id}`, address = new URL(path, url);
      address.protocol = url.protocol === "https:" ? "wss:" : "ws:";
      try {
        const headers = await sign(url, path, body.apiKey, token);
        if (ticket === generation) await sockets.open({ id, url: address.href, headers });
      } catch {
        retry(id);
      }
    };
    const retry = (id) => {
      if (ticket !== generation || retries.has(id)) return;
      const state = states.get(id);
      if (!state) return;
      state.connected = false;
      const count = attempts.get(id) || 0;
      attempts.set(id, count + 1);
      retries.set(id, setTimeout(() => {
        retries.delete(id);
        connect(id);
      }, Math.min(3e4, 1e3 * 2 ** Math.min(count, 5))));
    };
    listener = await sockets.addListener("socketEvent", (event) => {
      if (ticket !== generation) return;
      const state = states.get(event.id);
      if (!state) return;
      if (event.type === "open") {
        state.connected = true;
        attempts.set(event.id, 0);
      } else if (event.type === "message") {
        try {
          applyFieldEvent(state, JSON.parse(event.data), now());
        } catch {
        }
      } else if (event.type === "close" || event.type === "error") retry(event.id);
    });
    if (snapshotOperation !== operation) {
      await close();
      throw Error("TM connection cancelled.");
    }
    for (const set of sets) {
      const id = `${ticket}:${set.id}`;
      states.set(id, { ...set, connected: false, fields: set.fields.map((f) => ({ ...f, active: false, status: "unknown", match: null })) });
      await connect(id);
    }
  };
  const json = (result) => typeof result.data === "string" ? JSON.parse(result.data) : result.data;
  return {
    async request(route, body) {
      if (route === "disconnect") {
        if (!body.connectionId || !connectionId || body.connectionId === connectionId) {
          operation++;
          await close();
        }
        return {};
      }
      if (route === "activity") {
        if (!connectionId || body.connectionId !== connectionId || now() > leaseUntil) {
          await close();
          throw Error("TM live field connection expired. Reconnect TM.");
        }
        return { fieldSets: [...states.values()].map((s) => ({ ...s, fields: s.fields.map((f) => ({ ...f })) })), checkedAt: now() };
      }
      if (route !== "snapshot") throw Error("Unknown TM request.");
      const snapshotOperation = ++operation;
      const current = () => {
        if (snapshotOperation !== operation) throw Error("TM connection cancelled.");
      };
      const url = new URL(normalizeTmAddress(body.address));
      if (!body.apiKey?.trim() || !body.authorization?.startsWith("Bearer ") || !body.anonKey) throw Error("Enter the event API key and sign in to Ref OS.");
      if (body.division != null && (!Number.isSafeInteger(body.division) || body.division < 1)) throw Error("Choose a TM division.");
      if (!cloudUrl?.startsWith("https://")) throw Error("Ref OS Cloud is not configured.");
      const authResult = await http({ url: `${cloudUrl}/functions/v1/tm-api-token`, method: "POST", headers: { Authorization: body.authorization, apikey: body.anonKey, "Content-Type": "application/json" }, data: { eventId: body.eventId }, responseType: "json", connectTimeout: 15e3, readTimeout: 2e4, disableRedirects: true });
      const auth = json(authResult);
      current();
      if (authResult.status !== 200 || typeof auth?.accessToken !== "string") throw Error(auth?.error || "TM authorization failed.");
      const get = async (path) => {
        const result = await http({ url: new URL(path, url).href, method: "GET", headers: await sign(url, path, body.apiKey, auth.accessToken), responseType: "json", connectTimeout: 15e3, readTimeout: 2e4, disableRedirects: true });
        current();
        if (result.status === 401 || result.status === 403) throw Error("TM rejected the event key or request signature. Check the key and device clock.");
        if (result.status !== 200) throw Error("Could not read TM data. Check the server address and event Wi-Fi.");
        return json(result);
      };
      const [event, divisions] = await Promise.all([get("/api/event"), get("/api/divisions")]);
      if (body.division == null) {
        await close();
        return { event: event.event, divisions: divisions.divisions };
      }
      if (!divisions.divisions?.some((d) => d.id === body.division)) throw Error("This TM division no longer exists. Load the event again.");
      if (body.checkInOnly === true) {
        const teams2 = await get(`/api/teams/${body.division}`);
        return { multiServer: true, event: event.event, teams: teams2.teams, matches: [], rankings: [], skills: [] };
      }
      const [teams, matches, rankings, skills] = await Promise.all([get(`/api/teams/${body.division}`), get(`/api/matches/${body.division}`), get(`/api/rankings/${body.division}/QUAL`), get("/api/skills")]);
      let fieldError = "";
      if (body.liveFields) {
        try {
          const { fieldSets } = await get("/api/fieldsets");
          if (!Array.isArray(fieldSets) || fieldSets.length > 30) throw Error("Invalid field sets");
          const sets = await Promise.all(fieldSets.map(async (set) => {
            if (!Number.isSafeInteger(set.id) || set.id < 1) throw Error("Invalid field set");
            const { fields } = await get(`/api/fieldsets/${set.id}/fields`);
            if (!Array.isArray(fields) || fields.length > 30 || fields.some((f) => !Number.isSafeInteger(f.id) || f.id < 1)) throw Error("Invalid fields");
            return { id: set.id, name: String(set.name || `Field set ${set.id}`), fields: fields.map((f) => ({ id: f.id, name: String(f.name || `Field ${f.id}`) })) };
          }));
          current();
          await configure(url, body, auth.accessToken, sets, snapshotOperation);
        } catch {
          current();
          await close();
          fieldError = "Live fields could not connect. Scores and rankings can still sync.";
        }
      } else await close();
      return { event: event.event, divisions: divisions.divisions, teams: teams.teams, matches: matches.matches, rankings: rankings.rankings, skills: skills.skillsRankings, connectionId, fieldError };
    },
    async close() {
      operation++;
      await close();
    }
  };
}

// src/tmClientPool.js
function createTmClientPool(createClient, { http, sockets, cloudUrl }) {
  const clients = /* @__PURE__ */ new Map(), connections = /* @__PURE__ */ new Map();
  const make2 = (channel) => {
    const ids = /* @__PURE__ */ new Set(), prefix = channel + ":";
    const scoped = {
      sign: (options) => sockets.sign(options),
      open: async (options) => {
        ids.add(options.id);
        return sockets.open({ ...options, id: prefix + options.id });
      },
      closeAll: async () => {
        for (const id of ids) await sockets.close({ id: prefix + id });
        ids.clear();
      },
      addListener: async (name, listener) => sockets.addListener(name, (event) => {
        if (event.id?.startsWith(prefix)) listener({ ...event, id: event.id.slice(prefix.length) });
      })
    };
    return createClient({ http, sockets: scoped, cloudUrl });
  };
  const request = async (route, body) => {
    const channel = route === "snapshot" ? body.channelId || "default" : connections.get(body.connectionId) || "default";
    if (!/^[a-zA-Z0-9_-]{1,80}$/.test(channel)) throw Error("Invalid TM connection.");
    if (!clients.has(channel)) {
      if (clients.size >= 3) throw Error("Too many TM connections. Reopen the app.");
      clients.set(channel, make2(channel));
    }
    const result = await clients.get(channel).request(route, body);
    if (result.connectionId) {
      for (const [id, value] of connections) if (value === channel) connections.delete(id);
      connections.set(result.connectionId, channel);
    }
    if (route === "disconnect") {
      for (const [id, value] of connections) if (value === channel) connections.delete(id);
    }
    return route === "snapshot" ? { ...result, multiServer: true } : result;
  };
  request.closeAll = async () => {
    await Promise.all([...clients.values()].map((client) => client.close()));
    clients.clear();
    connections.clear();
  };
  return request;
}

// browser-extension/security.js
var CLOUD = "https://gcibsphjcllspzesqqsw.supabase.co";
var websiteAllowed = (value) => {
  try {
    const u = new URL(value);
    return u.protocol === "https:" && ["www.ref-os.fyi", "ref-os.fyi"].includes(u.hostname) && !u.port;
  } catch {
    return false;
  }
};
var hostPattern = (value) => {
  const u = new URL(normalizeTmAddress(value));
  return `${u.protocol}//${u.hostname}/*`;
};
var hostPatterns = (value) => {
  const pattern = hostPattern(value);
  return [pattern, pattern.replace(/^http:/, "ws:").replace(/^https:/, "wss:")];
};
function validateRequest(route, body, address) {
  if (!["snapshot", "activity", "disconnect"].includes(route) || !body || typeof body !== "object" || JSON.stringify(body).length > 25e3) throw Error("Invalid TM extension request.");
  if (route === "snapshot") {
    if (!address || normalizeTmAddress(body.address) !== address) throw Error("Open the Ref OS extension, allow this TM server address, then retry.");
    if (typeof body.apiKey !== "string" || body.apiKey.length > 2e3 || typeof body.authorization !== "string" || body.authorization.length > 12e3 || typeof body.anonKey !== "string" || body.anonKey.length > 4e3 || typeof body.eventId !== "string" || body.eventId.length > 100) throw Error("Enter the event key and sign in to Ref OS.");
  }
}
function allowedHttp(value, method, address) {
  const url = new URL(value);
  if (url.origin === CLOUD && url.pathname === "/functions/v1/tm-api-token" && method === "POST" && !url.search) return true;
  return url.origin === address && method === "GET" && !url.search && /^\/api\/(event|divisions|skills|teams\/\d+|matches\/\d+|rankings\/\d+\/QUAL|fieldsets|fieldsets\/\d+\/fields)$/.test(url.pathname);
}
function signedSocketRule(id, url, headers, extensionId) {
  const u = new URL(url);
  if (!["ws:", "wss:"].includes(u.protocol) || !/^\/api\/fieldsets\/\d+$/.test(u.pathname) || u.search || u.username || u.password) throw Error("Invalid TM live field address.");
  return { id, priority: 1, action: { type: "modifyHeaders", requestHeaders: Object.entries(headers).map(([header, value]) => ({ header, operation: "set", value })) }, condition: { regexFilter: "^" + url.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "$", initiatorDomains: [extensionId], resourceTypes: ["websocket"] } };
}

// browser-extension/sockets.js
function createExtensionSockets({ chrome: chrome2, WebSocketClass = WebSocket, allowed }) {
  const sockets = /* @__PURE__ */ new Map(), listeners = /* @__PURE__ */ new Set();
  let sequence = 1, tail = Promise.resolve();
  const emit = (event) => {
    for (const fn of listeners) fn(event);
  };
  const close = async ({ id }) => {
    const row = sockets.get(id);
    if (!row) return;
    sockets.delete(id);
    row.socket.close();
    row.cancel?.();
  };
  return {
    async addListener(_name, listener) {
      listeners.add(listener);
      return { remove: async () => listeners.delete(listener) };
    },
    close,
    async closeAll() {
      await Promise.all([...sockets.keys()].map((id) => close({ id })));
    },
    open(options) {
      const run = tail.then(async () => {
        await allowed(options.url);
        await close({ id: options.id });
        const ruleId = sequence++;
        const rule = signedSocketRule(ruleId, options.url, options.headers, chrome2.runtime.id);
        await chrome2.declarativeNetRequest.updateSessionRules({ addRules: [rule] });
        try {
          await new Promise((resolve, reject) => {
            const socket = new WebSocketClass(options.url);
            let settled = false;
            const finish = (error) => {
              if (settled) return;
              settled = true;
              clearTimeout(timer);
              error ? reject(error) : resolve();
            };
            const timer = setTimeout(() => {
              socket.close();
              finish(Error("TM live field connection timed out."));
            }, 12e3);
            sockets.set(options.id, { socket, cancel: () => finish(Error("TM live field connection cancelled.")) });
            socket.onopen = () => {
              emit({ id: options.id, type: "open" });
              finish();
            };
            socket.onmessage = (e) => {
              if (typeof e.data === "string" && e.data.length <= 1e5) emit({ id: options.id, type: "message", data: e.data });
            };
            socket.onerror = () => {
              emit({ id: options.id, type: "error" });
              finish(Error("TM live field connection failed. Check its API support and network permissions."));
            };
            socket.onclose = () => {
              if (sockets.get(options.id)?.socket === socket) sockets.delete(options.id);
              emit({ id: options.id, type: "close" });
              finish(Error("TM live field connection closed."));
            };
          });
        } finally {
          await chrome2.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] });
        }
      });
      tail = run.catch(() => {
      });
      return run;
    }
  };
}

// browser-extension/background.js
var tabs = /* @__PURE__ */ new Map();
var init = (async () => {
  const rules = await chrome.declarativeNetRequest.getSessionRules();
  if (rules.length) await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: rules.map((r) => r.id) });
})();
var nextRule = 1;
var proxySockets = /* @__PURE__ */ new Map();
var creatingDocument;
async function ensureDocument() {
  if ((await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] })).length) return;
  creatingDocument ||= chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["IFRAME_SCRIPTING"], justification: "Script an extension iframe for signed Tournament Manager live field WebSocket connections while Ref OS is syncing." }).finally(() => {
    creatingDocument = null;
  });
  await creatingDocument;
}
var FieldSocket = class {
  constructor(url) {
    this.id = crypto.randomUUID();
    proxySockets.set(this.id, this);
    queueMicrotask(() => chrome.runtime.sendMessage({ target: "refos-live-document", type: "open", id: this.id, url }).catch(() => this.onerror?.()));
  }
  close() {
    chrome.runtime.sendMessage({ target: "refos-live-document", type: "close", id: this.id }).catch(() => {
    });
    proxySockets.delete(this.id);
  }
};
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.target !== "refos-live-event" || sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("offscreen.html")) return;
  const event = message.event, socket = proxySockets.get(event?.id);
  if (!socket) return;
  if (event.type === "message") socket.onmessage?.({ data: event.data });
  else if (event.type === "open") socket.onopen?.();
  else if (event.type === "error") socket.onerror?.();
  else if (event.type === "close") {
    socket.onclose?.();
    proxySockets.delete(event.id);
  }
});
var handshake = Promise.resolve();
async function addressAllowed(value) {
  const { address } = await chrome.storage.local.get("address");
  const u = new URL(value);
  const origin = u.origin.replace(/^ws:/, "http:").replace(/^wss:/, "https:");
  if (origin !== address || !await chrome.permissions.contains({ origins: hostPatterns(address) })) throw Error("Allow this TM server in the Ref OS extension first.");
}
function make(tab) {
  const socketBase = createExtensionSockets({ WebSocketClass: FieldSocket, chrome: { runtime: chrome.runtime, declarativeNetRequest: { updateSessionRules: async (options) => {
    if (options.addRules) {
      for (const rule of options.addRules) {
        const old = rule.id;
        rule.id = nextRule++;
        ids.set(old, rule.id);
      }
    }
    if (options.removeRuleIds) options.removeRuleIds = options.removeRuleIds.map((id) => {
      const actual = ids.get(id);
      ids.delete(id);
      return actual;
    });
    return chrome.declarativeNetRequest.updateSessionRules(options);
  } } }, allowed: async (value) => {
    await addressAllowed(value);
    await ensureDocument();
  } });
  const ids = /* @__PURE__ */ new Map();
  const sockets = { ...socketBase, sign: async ({ key, message }) => {
    const encoder = new TextEncoder();
    const secret = await crypto.subtle.importKey("raw", encoder.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const bytes = await crypto.subtle.sign("HMAC", secret, encoder.encode(message));
    return { signature: [...new Uint8Array(bytes)].map((n) => n.toString(16).padStart(2, "0")).join("") };
  }, open: (options) => {
    const task = handshake.then(() => socketBase.open(options));
    handshake = task.catch(() => {
    });
    return task;
  } };
  const http = async (options) => {
    const { address } = await chrome.storage.local.get("address");
    if (!allowedHttp(options.url, options.method, address)) throw Error("TM extension request destination is not allowed.");
    if (new URL(options.url).origin !== CLOUD) await addressAllowed(options.url);
    const response = await fetch(options.url, { method: options.method, headers: options.headers, body: options.method === "POST" ? JSON.stringify(options.data) : void 0, redirect: "error", credentials: "omit", cache: "no-store", signal: AbortSignal.timeout(2e4) });
    const text = await response.text();
    if (text.length > 12e6) throw Error("TM response is too large.");
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw Error("TM returned an unreadable response. Check the server address and school sign-in page.");
    }
    return { status: response.status, data };
  };
  const request = createTmClientPool(createMobileTmClient, { http, sockets, cloudUrl: CLOUD });
  return { request, sockets, last: Date.now(), tab };
}
async function closeTab(id) {
  const state = tabs.get(id);
  if (state) {
    tabs.delete(id);
    await state.request.closeAll();
    if (!tabs.size) await chrome.offscreen.closeDocument().catch(() => {
    });
  }
}
chrome.tabs.onRemoved.addListener((id) => {
  void closeTab(id);
});
chrome.tabs.onUpdated.addListener((id, change) => {
  if (change.status === "loading") void closeTab(id);
});
chrome.permissions.onRemoved.addListener(() => {
  for (const id of tabs.keys()) void closeTab(id);
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.address) for (const id of tabs.keys()) void closeTab(id);
});
setInterval(() => {
  for (const [id, state] of tabs) {
    if (Date.now() - state.last > 9e4) void closeTab(id);
  }
}, 2e4);
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.target !== "refos-tm") return;
  (async () => {
    await init;
    if (!sender.tab || sender.frameId !== 0 || !websiteAllowed(sender.url)) throw Error("Open the official Ref OS website to use this extension.");
    if (message.route === "credentials") {
      const { address: address2 } = await chrome.storage.local.get("address");
      const { tmCredentials } = await chrome.storage.session.get("tmCredentials");
      return { address: address2 || "", apiKey: tmCredentials?.address === address2 ? tmCredentials.apiKey : "" };
    }
    if (message.route === "ping") return { available: true, version: "1.0.0", liveFields: true };
    const { address } = await chrome.storage.local.get("address");
    validateRequest(message.route, message.body, address);
    if (message.route === "snapshot") await addressAllowed(address);
    let state = tabs.get(sender.tab.id);
    if (!state) {
      if (tabs.size >= 4) throw Error("Too many Ref OS tabs are connected. Close another tab first.");
      state = make(sender.tab.id);
      tabs.set(sender.tab.id, state);
    }
    state.last = Date.now();
    try {
      return await state.request(message.route, message.body);
    } catch (error) {
      throw Error(/^(TM |Enter |Use |Choose |This TM|Event administrator|Sign in|Allow |Open |Could not)/.test(error.message) ? error.message : "Could not connect to TM. Check the extension\u2019s allowed server, event Wi-Fi and internet connection.");
    }
  })().then((data) => reply({ ok: true, data }), (error) => reply({ ok: false, error: error.message }));
  return true;
});
